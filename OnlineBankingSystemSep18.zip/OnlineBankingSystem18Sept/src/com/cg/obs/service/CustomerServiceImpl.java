package com.cg.obs.service;

import com.cg.obs.dao.CustomerDaoImpl;
import com.cg.obs.exception.BankException;

public class CustomerServiceImpl implements CustomerService {

	CustomerDaoImpl dao;
	
	public CustomerServiceImpl() {
		dao = new CustomerDaoImpl();
	}

	@Override
	public void addCustomer(String custName, String custEmail, String custAddr, String custPAN, long custMob,
			long accId) throws BankException {
		
		dao.addCustomer(custName, custEmail, custAddr, custPAN, custMob, accId);

	}


	@Override
	public void updateMobile(long accNo, long new_number) throws BankException {
		dao.updateMobile(accNo, new_number);
		
	}

	@Override
	public void updateAddress(long accNo, String address) throws BankException {
		dao.updateAddress(accNo, address);
		
	}

	@Override
	public long getMobile(long accNo) throws BankException {
		// TODO Auto-generated method stub
		return dao.getMobile(accNo);
	}

	@Override
	public String getAddress(long accNo) throws BankException {
		// TODO Auto-generated method stub
		return dao.getAddress(accNo);
	}

}
