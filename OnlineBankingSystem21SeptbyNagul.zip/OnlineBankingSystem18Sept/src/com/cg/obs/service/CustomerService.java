package com.cg.obs.service;

import com.cg.obs.exception.BankException;

public interface CustomerService {

	public void addCustomer(String custName, String custEmail, String custAddr, String custPAN, long custMob, long accId) throws BankException;
	public void updateMobile(long accNo, long new_number)throws BankException;
	public void updateAddress(long accNo, String address)throws BankException;
	public long getMobile(long accNo)throws BankException;
	public String getAddress(long accNo)throws BankException;
}
