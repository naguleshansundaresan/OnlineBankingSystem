package com.cg.obs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

import com.cg.obs.exception.BankException;
import com.cg.obs.util.DBUtil;

public class ServiceTrackerDaoImpl implements ServiceTrackerDao
{
	static Connection con=DBUtil.getconnection();
	Statement st;
	PreparedStatement pst;
	public int requestCheque(long accNo) throws BankException {
		int dataInserted=0;
		String desc="Checkbook Request";
		String status="Open";
			try {
		
			pst = con.prepareStatement(QueryMapper.ADD_CHEQUE_REQUEST);
			pst.setString(1, desc);
			pst.setLong(2, accNo);
			pst.setString(3, status);
			
		
			dataInserted = pst.executeUpdate();
			
		} catch (SQLException e) {
			throw new BankException(e.getMessage());
		}
		return dataInserted;
	}
	
		public String searchByServNo(int reqNo) throws BankException {
		String status=null;
			try {
		
			pst = con.prepareStatement(QueryMapper.GET_SERVICE_STATUS);
			pst.setInt(1, reqNo);
			
			
		
			ResultSet rs=pst.executeQuery();
			if(rs.next())
			status = rs.getString(1);
			
		} catch (SQLException e) {
			throw new BankException(e.getMessage());
		}
		return status;
	}
		
		@Override
		public HashMap<Integer,String> searchByAccNo(long accNo) throws BankException {

			int flag=0;
			HashMap<Integer, String> map = new HashMap<>();
			
				try {
					pst=con.prepareStatement(QueryMapper.GET_SERVICE_STATUS_BY_ACC);
					pst.setLong(1, accNo);
				
				ResultSet rs=pst.executeQuery();
							while(rs.next())
							{
								flag=1;
								map.put(rs.getInt(1),rs.getString(5));
								
							}
						if(flag==0)
						{
							throw new BankException("The account number chosen is invalid");
						}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new BankException(e.getMessage());
				}
			
			return map;
		}
		
		@Override
		public HashMap<Integer, String> searchByRequestNo(int serNum, long accNo)throws BankException {
			HashMap<Integer, String> map = new HashMap<>();
			int flag=0;
			try {
				pst=con.prepareStatement(QueryMapper.GET_SERVICE_STATUS_BY_REQ);
				pst.setLong(1, accNo);
				pst.setInt(2, serNum);
				ResultSet rs=pst.executeQuery();
						while(rs.next())
						{
							flag=1;
							map.put(rs.getInt(1),rs.getString(5));
							
						}
				if(flag==0)
				{
					throw new BankException("Either the account number or service request number is invalid");
				}
			} catch (Exception e) {
				throw new BankException(e.getMessage());
			}
		
		return map;
		}



}
