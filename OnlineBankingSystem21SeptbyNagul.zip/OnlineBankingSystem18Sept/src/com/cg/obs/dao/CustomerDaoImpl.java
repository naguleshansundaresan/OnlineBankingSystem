package com.cg.obs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.obs.exception.BankException;
import com.cg.obs.util.DBUtil;

public class CustomerDaoImpl implements CustomerDao
{
	static Connection con=DBUtil.getconnection();
	Statement st;
	PreparedStatement pst;
	
	
	@Override
	public void addCustomer(String custName, String custEmail, String custAddr, String custPAN, long custMob, long accId) throws BankException
	{
		try {
			pst=con.prepareStatement(QueryMapper.CREATE_ACCOUNT_CUSTOMER);
			pst.setLong(1, accId);
			pst.setString(2, custName);
			pst.setString(3, custEmail);
			pst.setString(4, custAddr);
			pst.setString(5, custPAN);
			pst.setLong(6, custMob);
			int upd=pst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new BankException(e.getMessage());
		}
		
	}


	@Override
	public void updateMobile(long accNo, long new_number) throws BankException {
		try {
			pst=con.prepareStatement(QueryMapper.UPDATE_MOBILE);
			pst.setLong(1, new_number);
			pst.setLong(2, accNo);
			int upd=pst.executeUpdate();
			if(upd>0)
				System.out.println("Mobile number updated successfully!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new BankException(e.getMessage());
		}
		
	}


	@Override
	public void updateAddress(long accNo, String address) throws BankException {
		try {
			pst=con.prepareStatement(QueryMapper.UPDATE_ADDRESS);
			pst.setString(1, address);
			pst.setLong(2, accNo);
			int upd=pst.executeUpdate();
			if(upd>0)
				System.out.println("Address updated successfully!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new BankException(e.getMessage());
		}
		
	}


	@Override
	public long getMobile(long accNo) throws BankException {
		long mob=0;
		try {
			pst=con.prepareStatement(QueryMapper.GET_MOBILE);
			pst.setLong(1, accNo);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				mob = rs.getLong(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new BankException(e.getMessage());
		}
		return mob;
	}


	@Override
	public String getAddress(long accNo) throws BankException {
		String addr="";
		try {
			pst=con.prepareStatement(QueryMapper.GET_ADDRESS);
			pst.setLong(1, accNo);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				addr = rs.getString(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new BankException(e.getMessage());
		}
		return addr;
	}




}
