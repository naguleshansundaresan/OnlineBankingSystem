package com.cg.obs.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.obs.dao.AccountMasterDaoImpl;
import com.cg.obs.dto.AccountMaster;
import com.cg.obs.exception.BankException;

public class AccountMasterServiceImpl implements AccountMasterService {

	AccountMasterDaoImpl dao;
	public AccountMasterServiceImpl() {
		dao = new AccountMasterDaoImpl();	
	}

	@Override
	public boolean addAccount(String custName, String custEmail, String custAddr, String custPAN, String custPwd,
			String custQues, String custTPwd, String accType, long custMob, double balance) throws BankException {
		
		return dao.addAccount(custName, custEmail, custAddr, custPAN, custPwd, custQues, custTPwd, accType, custMob, balance);
	}

	@Override
	public ArrayList<AccountMaster> getBalance(long uid) throws BankException {
		
		return dao.getBalance(uid);
	}

	@Override
	public boolean validatePassword(String custPwd) {
		String pwdPattern = "((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})";
		if(Pattern.matches(pwdPattern, custPwd))
		{
			return true;
		}
		return false;
	}
	
	/* (    # Start of group
 	(?=.*\d)		#   must contains one digit from 0-9
	(?=.*[a-z])		#   must contains one lowercase characters
	(?=.*[A-Z])		#   must contains one uppercase characters
	(?=.*[@#$%])		#   must contains one special symbols in the list "@#$%"
	 .		#     match anything with previous condition checking
	{6,20}	#        length at least 6 characters and maximum of 20	
	)
*/

	@Override
	public boolean validateMail(String custEmail) {
		String mailPattern = "^[_A-Za-z0-9-\\\\+]+(\\\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\\\.[A-Za-z0-9]+)*(\\\\.[A-Za-z]{2,})$";
		if(Pattern.matches(mailPattern, custEmail))
		{
			return true;
		}
		return false;
	}


	
	
	@Override
	public boolean validateMobileNumber(long custMob) {
		String custMobile = new Long(custMob).toString();
		String mobilePattern = "[0-9]{10}";
		if(Pattern.matches(mobilePattern, custMobile))
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean validateName(String custName) {
		String namePattern = "[A-Z]([a-z])*{5,20}";
		if(Pattern.matches(namePattern, custName))
		{
			return true;
		}
		return false;
	}

	@Override
	public boolean confirmPassword(String custPwd, String confirmPwd) {
		if(custPwd.equals(confirmPwd))
			return true;
		
		return false;
	}

}
