package com.cg.obs.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

import com.cg.obs.dto.AccountMaster;
import com.cg.obs.dto.Customer;
import com.cg.obs.dto.PayeeTable;
import com.cg.obs.dto.Transactions;
import com.cg.obs.dto.UserTable;
import com.cg.obs.exception.BankException;
import com.cg.obs.service.AccountMasterServiceImpl;
import com.cg.obs.service.FundTransferServiceImpl;
import com.cg.obs.service.PayeeServiceImpl;
import com.cg.obs.service.ServiceTrackerServiceImpl;
import com.cg.obs.service.TransactionServiceImpl;
import com.cg.obs.service.UserTableServiceImpl;
import com.cg.obs.util.DBUtil;

public class OnlineBankingSystemUI {

	//Service 
	static UserTableServiceImpl userService;
	static TransactionServiceImpl transactionService;
	static AccountMasterServiceImpl accountService;
	static ServiceTrackerServiceImpl serviceTrackerService;  
	static FundTransferServiceImpl fundTransferService;
	static PayeeServiceImpl payeeService;
	//Dto
	static Customer customer;
	static UserTable usertable;
	
	//inputstream 
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	
	//static variables
	static int choice = 0;
	static int userId;
	static String adminId;
	static String userPassword;
	static String adminPassword;
	
	public OnlineBankingSystemUI()
	{
		userService = new UserTableServiceImpl();
		transactionService = new TransactionServiceImpl();
		accountService = new AccountMasterServiceImpl();
		serviceTrackerService = new ServiceTrackerServiceImpl();
		fundTransferService = new FundTransferServiceImpl();
		payeeService = new PayeeServiceImpl(); 
	}
	private static void userHomePage(int userId) throws NumberFormatException, IOException
	{
		System.out.println("*****************************************HomePage***************************************************\n\n\n");
		System.out.println("\t\t Welcome "+ customer.getCustomer_name() +"  to our Online Banking System");
		try {
			int userChoice;
			ArrayList<AccountMaster> allAccounts = accountService.getBalance(userId);
			for(AccountMaster account : allAccounts)
				System.out.println("Your Balance for the Account Number "+ account.getAccount_id() + " is Rs." + account.getAccount_balance());

			System.out.println("1. View Mini/Detailed statement \n2.Change in address/mobile number \n3.Request for Cheque Book \n4.Track Service request \n5.Fund Transfer \n6.Change Password");
			userChoice = Integer.parseInt(br.readLine());
			switch(userChoice)
			{
			case 1: viewMini(customer.getAccount_id());
					break;
			case 2: //dao is yet to be implemented
					break;
			case 3: requestCheque();
					break;
			case 4: System.out.println("Enter the Account Number to be searched");
					long accNo = Long.parseLong(br.readLine());
					searchByAccNo(accNo);
					break;
			case 5: fundTransfer();
					break;
			case 6:	changePwd(userId);
					break;
			default:
				    System.out.println("Enter a valid choice");
					
			}
		}
		catch (BankException e) 
		{
			System.out.println(e);
			//e.printStackTrace();
		}
		catch(IOException e)
		{
		e.printStackTrace();
		}
	}

	private static void login()
	{
		try
		{
		OnlineBankingSystemUI obs = new OnlineBankingSystemUI();
		boolean userLogin;
		boolean adminLogin;
		System.out.println("**********************************************Welcome to Online Banking System**********************************************\n\n\n");
		System.out.println("Login as : 1.User \n2.Admin\n\n\t\t\t\t");
		String logger = br.readLine();
		if(logger.equals("1"))
		{
			System.out.println("Enter your userId:	");
			userId = Integer.parseInt(br.readLine());
			try {
				if(userService.validateUserId(userId) == true)
					{
					System.out.println("Enter your password:	");
					userPassword = br.readLine();
					userLogin = userService.validateLogin(userId, userPassword);
						if(userLogin == true ) // need to add & user.lockStatus == false
							{
							customer = transactionService.getData(userId); 
							userHomePage(userId);
							System.out.println("1.User Home Page 2.Logout");
							
							choice = Integer.parseInt(br.readLine());
							while(choice == 1)
							{
								userHomePage(userId);							
								choice = 0;
								System.out.println("1.User Home Page 2.Logout");
								choice = Integer.parseInt(br.readLine());
							}
							}
					}
			}
			catch (BankException e) 
			{
				//e.printStackTrace();
				System.out.println(e);
			}
		}
		else if(logger.equals("2"))  //admin part
		{
			
			System.out.println("Enter Id:	");
			adminId = br.readLine();
			try {

					System.out.println("Enter your password:	");
					adminPassword = br.readLine();
					System.out.println(adminId+"  "+adminPassword);
					if(userService.validateAdminLogin(adminId,adminPassword) == true)
					{
							adminHomePage(adminId);
							System.out.println("1.Admin Home Page 2.Logout");
							
							choice = Integer.parseInt(br.readLine());
							while(choice == 1)
							{
								adminHomePage(adminId);								
								choice = 0;
								System.out.println("1.Admin Home Page 2.Logout");
								choice = Integer.parseInt(br.readLine());
							}
							
					}
			}
			catch (BankException e) 
			{
				e.printStackTrace();
				System.out.println(e);
			}
			
		}
		else
		{
			System.out.println("Enter a valid input");
		}
		}
	catch(IOException e)
		{
		e.printStackTrace();
		}
		
	}

	public static void main(String[] args) 

	{
		login();
		
		System.exit(1);
		/*
		try
		{
		OnlineBankingSystemUI obs = new OnlineBankingSystemUI();
		boolean userLogin;
		boolean adminLogin;
		System.out.println("**********************************************Welcome to Online Banking System**********************************************\n\n\n");
		System.out.println("Login as : 1.User \n2.Admin\n\n\t\t\t\t");
		String logger = br.readLine();
		if(logger.equals("1"))
		{
			System.out.println("Enter your userId:	");
			userId = Integer.parseInt(br.readLine());
			try {
				if(userService.validateUserId(userId) == true)
					{
					System.out.println("Enter your password:	");
					userPassword = br.readLine();
					userLogin = userService.validateLogin(userId, userPassword);
						if(userLogin == true ) // need to add & user.lockStatus == false
							{
							customer = transactionService.getData(userId); 
							userHomePage(userId);
							}
					}
			}
			catch (BankException e) 
			{
				//e.printStackTrace();
				System.out.println(e);
			}
		}
		else if(logger.equals("2"))  //admin part
		{
			System.out.println("Enter Id:	");
			adminId = br.readLine();
			try {

					System.out.println("Enter your password:	");
					adminPassword = br.readLine();
					System.out.println(adminId+"  "+adminPassword);
					if(userService.validateAdminLogin(adminId,adminPassword) == true)
					{
							adminHomePage(adminId);
							
					}
			}
			catch (BankException e) 
			{
				e.printStackTrace();
				System.out.println(e);
			}
			
		}
		else
		{
			System.out.println("Enter a valid input");
		}
		}
	catch(IOException e)
		{
		e.printStackTrace();
		}*/
	}
	
	private static void adminHomePage(String adminId)
	{
		
		System.out.println("*****************************************HomePage***************************************************\n\n\n");
		System.out.println("\t\t Welcome admin to our Online Banking System");
		try {
			int adminChoice;
			System.out.println("1.Create New Account page\n2.View transactions of all accounts\n");
			adminChoice=Integer.parseInt(br.readLine());
			switch(adminChoice)
			{
			case 1:{createNewAccount();
					adminHomePage(adminId);
					break;}
			case 2:viewAllTransactions();
					break;
			default:System.out.println("Invalid input");
			}
	}
		
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	
			
	
	private static void viewAllTransactions() {
		int period;
		System.out.println("1.Daily transactions 2.Monthly transaction 3.Yearly transactions");
		try
		{
		int userchoice=Integer.parseInt(br.readLine());
		ArrayList<Transactions> list;
		switch(userchoice)
		{
		case 1:System.out.println("Enter date");
				String date=br.readLine();
				DateTimeFormatter format=DateTimeFormatter.ofPattern("dd/MM/yyyy");

				LocalDate formatedDate=LocalDate.parse(date,format);
				list=transactionService.viewTransaction(formatedDate);
				for(Transactions trans:list)
				{
					System.out.println(trans);
				}
				break;
		case 2:System.out.println("Enter period 1,3,5,7,8,10,12");
				period=Integer.parseInt(br.readLine());
				list=transactionService.viewTransaction(period,"monthly");
				for(Transactions trans:list)
				{
					System.out.println(trans);
				}
				break;
		case 3:
			System.out.println("Enter year");
			period=Integer.parseInt(br.readLine());
			list=transactionService.viewTransaction(period,"yearly");
			for(Transactions trans:list)
			{
				System.out.println(trans);
			}
			break;
		}
		}
		catch (BankException e) 
		{
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
	}


	private static void createNewAccount(){
		
		try 
		{
			System.out.println("Enter Account Holder Name");
			String  custName= br.readLine();
			
			if(accountService.validateName(custName))
			{
			System.out.println("Enter Account Holder Password");
			String  custPwd= br.readLine();
			
			if(accountService.validatePassword(custPwd))
				{
				System.out.println("Confirm Password");				
				String  confPwd= br.readLine();
			
				if(accountService.confirmPassword(custPwd, confPwd))
				{
					System.out.println("Enter Account Holder Email");
					String  custEmail= br.readLine();
			
					if(accountService.validateMail(custEmail))
					{
						System.out.println("Enter Account Holder Address");
						String  custAddr= br.readLine();
						
						System.out.println("Enter Account Holder Pan");
						String  custPAN=(br.readLine());
						if(accountService.validatePAN(custPAN))
						{
							System.out.println("Enter Security Question");
							String custQues=(br.readLine());
			
							System.out.println("Enter Account Holder Transaction pin");
							String custTPwd= (br.readLine());
							if(accountService.validatePassword(custPwd))
							{
								System.out.println("Enter Account Type");
								String accType= (br.readLine());
			
								System.out.println("Enter Account holder's mobile no.");
								long custMob= Long.parseLong(br.readLine());
								if(accountService.validateMobileNumber(custMob))
								{
									System.out.println("Enter Account Holder's balance");
									double balance= Double.parseDouble(br.readLine());
									accountService.addAccount(custName, custEmail, custAddr, custPAN, custPwd, custQues, custTPwd, accType, custMob, balance);
								}
								else
									System.out.println("Enter a valid mobile number");
							}
							else
								System.out.println("Enter a valid Transaction Password");
						}
						else
							System.out.println("Enter a valid PAN");
					}
					else
						System.out.println("Enter a valid Mail ID");
					
				}				
				else
					System.out.println("Password does not match");
				}
				else
					System.out.println("Enter a valid User Password");
			}
			else
				System.out.println("Enter a valid UserName");
		} 
		catch (BankException e) 
		{
			System.out.println(e);
		}
		
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	

	private static void viewMini(long accNo)
	{
		try 
		{
			ArrayList<Transactions> list=transactionService.viewMini(accNo);
			try 
			{
				for(Transactions t1:list)
					System.out.println(t1);
			}
			catch (Exception e) 
			{
					// TODO Auto-generated catch block
					e.printStackTrace();
			}
		} 
		
		catch (BankException e) 
		{
			System.out.println(e);
			e.printStackTrace();
		}
				
	}
	
	private static void requestCheque()
	{
		try 
		{
			System.out.println("Select the Account Number from the given list :\n");
			ArrayList<Long> allAccounts = userService.getAccounts(userId);
			int listNo=0;
			for(long acc : allAccounts)
				{ System.out.println((++listNo)+"."+acc); }
			int userChoice = Integer.parseInt(br.readLine());
			if(userChoice >=1 && userChoice <= listNo)
			{
					long accNo = allAccounts.get(userChoice);
					if(serviceTrackerService.requestCheque(accNo)>0)
					{
						System.out.println("Cheque Book request is raised Successfully");
					}
					else
					{
						//if cheque request is already raised
						System.out.println("Your Cheque Book request is already raised. Track your service request.");
					}
			}
			else
				System.out.println("Enter valid choice ");			

		} 
		catch (BankException e) {
			System.out.println(e);
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
	}
	
	private static void searchByAccNo(long accNo) 
	{
		try 
		{
			HashMap<Integer,String> hmap=serviceTrackerService.searchByAccNo(accNo);
			Set<Entry<Integer,String>> hashSet=hmap.entrySet();
	        for(Entry<Integer,String> entry:hashSet ) {
	            System.out.println("id="+entry.getKey()+", Status="+entry.getValue());
	        }
		} 
		catch (BankException e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		
	}
	
	private static void changePwd(int userId)
	{
		try 
		{
			System.out.println("Enter new password");
			String newPwd=br.readLine();
			System.out.println("Confirm password");
			String confPwd=br.readLine();
			if(userService.confirmPassword(newPwd, confPwd))
			{
				boolean isChanged=userService.changePwd(userId, newPwd);
			
				if(isChanged)
				System.out.println("Password is changed successfully");
				else
				System.out.println("Operation cannot be completed");
			}
			else
				System.out.println("Password mismatch");
		} 
		catch (BankException e) {
			System.out.println(e);
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}

	private static boolean otherBankFundTransfer()
	{
		try
		{
		payeeService = new PayeeServiceImpl();
		System.out.println("From:	");
		System.out.println("\t\tSelect the Account Number from the below list");
		ArrayList<Long> allAccounts = userService.getAccounts(userId);
		int listNo=0;
		for(long acc : allAccounts)
		{ System.out.println((++listNo)+"."+acc); }
		int userChoice = Integer.parseInt(br.readLine());
		if(userChoice >=1 && userChoice <= listNo)
			{
				long fromAccNo = allAccounts.get(userChoice);
				System.out.println("To:	");
				System.out.println("\t\t1.Payee list 2.Add Payee and continue");
				userChoice = Integer.parseInt(br.readLine());
				if(userChoice==1)
				{
					System.out.println("\t\tSelect the Account Number from the Payee list");
					ArrayList<PayeeTable> payeeAccounts = payeeService.getPayee(fromAccNo);
					listNo=0;
					System.out.printf("%20s	%20s %20s","S.No","NickName","Account Id");
					for(PayeeTable payee : payeeAccounts)
					{ 
						System.out.printf("%20s	%20s %20s",(++listNo),payee.getNick_name(),payee.getPayee_account_id());
					}
						userChoice = Integer.parseInt(br.readLine());
						if(userChoice>=1 && userChoice<=listNo)	
						{	PayeeTable toAccNo = payeeAccounts.get(userChoice);
						
							System.out.println("Enter the amount to be transferred");
							int amt = Integer.parseInt(br.readLine());
							System.out.println("Enter the transaction password");
							String tranPwd = br.readLine();
							//Validation for transaction password pending
							System.out.println(transactionService.addTransaction(fromAccNo, toAccNo.getNick_name() , amt, tranPwd));
				
						}
						else
							System.out.println("Enter a valid input");
				}	
				else if(userChoice==2)
				{
					System.out.println("Enter Payee Nick Name");
					String  payeeName= br.readLine();
					
					System.out.println("Enter Payee Account Id");
					long payeeAccId =Long.parseLong(br.readLine());
					
					PayeeTable newPayee = new PayeeTable(fromAccNo, payeeAccId, payeeName);
					payeeService.addPayee(newPayee);
					
					System.out.println("Now proceed the transaction");
					
					System.out.println("To:	");
					System.out.println("Payee list");

						System.out.println("\t\tSelect the Account Number from the Payee list");
						ArrayList<PayeeTable> payeeAccounts = payeeService.getPayee(fromAccNo);
						listNo=0;
						System.out.printf("%20s	%20s %20s","S.No","NickName","Account Id");
						for(PayeeTable payee : payeeAccounts)
						{ 
							System.out.printf("%20s	%20s %20s",(++listNo),payee.getNick_name(),payee.getPayee_account_id());
						}
						userChoice = Integer.parseInt(br.readLine());
						if(userChoice>=1 && userChoice<=listNo)	
						{	PayeeTable toAccNo = payeeAccounts.get(userChoice);
						
							System.out.println("Enter the amount to be transferred");
							int amt = Integer.parseInt(br.readLine());
							System.out.println("Enter the transaction password");
							String tranPwd = br.readLine();
							//Validation for transaction password pending
							System.out.println(transactionService.addTransaction(fromAccNo, toAccNo.getNick_name() , amt, tranPwd));
				
						}
						else
							System.out.println("Enter a valid input");
			
				}
			}
		}
		catch (BankException e) {
			System.out.println(e);
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		return true;
	}
	
	private static boolean ownBankFundTransfer()
	{
		try
		{
		System.out.println("From:	");
		System.out.println("\t\tSelect the Account Number from the below list");
		ArrayList<Long> allAccounts = userService.getAccounts(userId);
		int listNo=0;
		for(long acc : allAccounts)
			{ System.out.println((++listNo)+"."+acc); }
		int userChoice = Integer.parseInt(br.readLine());
		if(userChoice >=1 && userChoice <= listNo)
		{
				long fromAccNo = allAccounts.get(userChoice);
		
				System.out.println("To:	");
				System.out.println("\t\tSelect the Account Number from the below list");
				listNo=0;
				for(long acc : allAccounts)
					{ ++listNo;
					if(listNo!=userChoice)
						System.out.println((listNo)+"."+acc); 
					}
				long toAccNo = allAccounts.get(userChoice);
				System.out.println("Enter the amount to be transferred");
				int amt = Integer.parseInt(br.readLine());
				System.out.println("Enter the transaction password");
				String tranPwd = br.readLine();
				//Validation for transaction password pending
				fundTransferService.transferToSelf(fromAccNo, toAccNo, amt);
				
		}	
		}
		catch (BankException e) {
			System.out.println(e);
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		return true;
	}
	private static void fundTransfer()
	{
		try 
		{
			fundTransferService = new FundTransferServiceImpl();
			System.out.println("*******************************Fund Transfer*******************************");
			System.out.println("1.Own Bank Account 2.Different Bank Account");
			int userChoice = Integer.parseInt(br.readLine());
			switch(userChoice)
			{
			case 1: ownBankFundTransfer();
					break;
			case 2: otherBankFundTransfer();
					break;
			default:
				    System.out.println("Enter a valid choice");
					
			}
			
			
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
}



