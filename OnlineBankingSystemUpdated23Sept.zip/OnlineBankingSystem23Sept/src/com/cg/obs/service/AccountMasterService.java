package com.cg.obs.service;

import java.util.ArrayList;

import com.cg.obs.dto.AccountMaster;
import com.cg.obs.exception.BankException;

public interface AccountMasterService {

	public boolean addAccount(int uid,String custName,String custEmail,String custAddr,String custPAN,String custPwd,String custQues,String custTPwd,String accType,long custMob, double balance) throws BankException;
	public ArrayList<AccountMaster> getBalance(long  uid) throws BankException;
	//All the below validations are changed by naguleshan on 23/09/2019
	//Change in implementation also...Except addAccount change all the other methods
	public boolean validatePassword(String custPwd); 
	public boolean validateMail(String custEmail);
	public boolean validateMobileNumber(long custMob);
	public boolean validateName(String custName);
	public boolean confirmPassword(String custPwd, String confirmPwd);
	public boolean validatePAN(String custPAN);
	public boolean validateUserId(int uId);
	public boolean validateTPwd(String custTPwd);
}
