package com.cg.obs.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

import com.cg.obs.dto.AccountMaster;
import com.cg.obs.dto.Customer;
import com.cg.obs.dto.PayeeTable;
import com.cg.obs.dto.Transactions;
import com.cg.obs.dto.UserTable;
import com.cg.obs.exception.BankException;
import com.cg.obs.service.AccountMasterServiceImpl;
import com.cg.obs.service.CustomerServiceImpl;
import com.cg.obs.service.FundTransferServiceImpl;
import com.cg.obs.service.PayeeServiceImpl;
import com.cg.obs.service.ServiceTrackerServiceImpl;
import com.cg.obs.service.TransactionServiceImpl;
import com.cg.obs.service.UserTableServiceImpl;

public class OnlineBankingSystemUI {

	//Service 
	static UserTableServiceImpl userService;
	static TransactionServiceImpl transactionService;
	static AccountMasterServiceImpl accountService;
	static ServiceTrackerServiceImpl serviceTrackerService;  
	static FundTransferServiceImpl fundTransferService;
	static PayeeServiceImpl payeeService;
	static CustomerServiceImpl customerService;
	//Dto
	static Customer customer;
	static UserTable usertable;
	
	//inputstream 
	static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	
	//static variables
	static int choice = 0;
	static int userId;
	static String adminId;
	static String userPassword;
	static String adminPassword;
	
	public OnlineBankingSystemUI()
	{
		userService = new UserTableServiceImpl();
		transactionService = new TransactionServiceImpl();
		accountService = new AccountMasterServiceImpl();
		serviceTrackerService = new ServiceTrackerServiceImpl();
		fundTransferService = new FundTransferServiceImpl();
		payeeService = new PayeeServiceImpl();
		customerService = new CustomerServiceImpl();
	}
	
	private static void userHomePage(int userId) throws NumberFormatException, IOException
	{
		System.out.println("*****************************************HomePage***************************************************\n");
		System.out.println("\t\t Welcome "+ customer.getCustomer_name() +"  to our Online Banking System\n");
		try {
			int userChoice;
			ArrayList<AccountMaster> allAccounts = accountService.getBalance(userId);
			for(AccountMaster account : allAccounts)
				System.out.println("Your Balance for the Account Number "+ account.getAccount_id() + " is Rs." + account.getAccount_balance());

			System.out.println("1. View Mini/Detailed statement \n2.Change in address/mobile number \n3.Request for Cheque Book \n4.Track Service request \n5.Fund Transfer \n6.Change Password");
			userChoice = Integer.parseInt(br.readLine());
			switch(userChoice)
			{
			case 1: statements();
					break;
			case 2: changeDetails(customer.getAccount_id());
					break;
			case 3: requestCheque();
					break;
			case 4: trackServiceRequest();
					break;
			case 5: fundTransfer();
					break;
			case 6:	changePwd(userId);
					break;		
			default:
				    System.out.println("Enter a valid choice");					
			}
		}
		catch (BankException e) 
		{
			System.out.println(e);
		}
		catch(IOException e)
		{
		e.printStackTrace();
		}
	}
	
	public static void statements()throws BankException, IOException{
		System.out.println("Enter\n1.To view mini statement\n2.To view detailed statement");
		int ch = Integer.parseInt(br.readLine());
		switch(ch){
		case 1:{ 
				viewMini(customer.getAccount_id());
				break;}
		case 2:{
				System.out.println("Enter start date");
				String date=br.readLine();
				DateTimeFormatter format=DateTimeFormatter.ofPattern("dd-MM-yyyy");
				LocalDate startDate=LocalDate.parse(date,format);
				System.out.println("Enter end date");
				String edate=br.readLine();
				LocalDate endDate=LocalDate.parse(edate,format);
				viewDetailed(customer.getAccount_id(), startDate, endDate);
		}
		}
	}
	
	public static void trackServiceRequest()throws BankException,IOException {
		System.out.println("Enter the Account Number to be searched");
		ArrayList<Long> allAccounts = userService.getAccounts(userId);
		int listNo=0;
		for(long acc : allAccounts)
			{ System.out.println((++listNo)+"."+acc); }
		long accNo = Long.parseLong(br.readLine());
		System.out.println("Enter your choice\n1.Status of a service request\n2.Status of all service requests ");
		int ch = Integer.parseInt(br.readLine());
		System.out.println(accNo);
		switch(ch) {
		case 1: {
				System.out.println("Enter service request number");
				int serNum = Integer.parseInt(br.readLine());
				searchByRequestNo(serNum,accNo);
				break;
				}
		case 2:	{							
				searchByAccNo(accNo);
				break;
				}
		default:System.out.println("Invalid choice");
			}
	}
	
	private static void searchByRequestNo(int serNum, long accNo) {
		try 
		{
			HashMap<Integer,String> hmap=serviceTrackerService.searchByRequestNo(serNum,accNo);
			Set<Entry<Integer,String>> hashSet=hmap.entrySet();
	        for(Entry<Integer,String> entry:hashSet ) {
	            System.out.println("id="+entry.getKey()+", Status="+entry.getValue());
	        }
		} 
		catch (BankException e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		
	}


	
	private static void changeDetails(long accNo)throws BankException
	{
		try{
			System.out.println("Choose an option \n 1.Update mobile number \n 2.Update address");
			int choice=Integer.parseInt(br.readLine());
			switch(choice)
			{
			case 1:{
					long number = customerService.getMobile(accNo);
					System.out.println("Your current mobile number is "+number);
					System.out.println("Enter your new mobile number");
					long new_number=Long.parseLong(br.readLine());
					boolean upd = customerService.updateMobile(accNo,new_number);
					if(upd==true)
						System.out.println("Mobile Number updated successfully!");
					break;}
			case 2:{
					String addr = customerService.getAddress(accNo);
					System.out.println("Your current address:"+addr);
					System.out.println("Enter your new address");
					String new_address=br.readLine();
					boolean upd = customerService.updateAddress(accNo,new_address);
					if(upd==true)
						System.out.println("Address updated successfully!");
					break;}
			default:System.out.println("Invalid choice");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new BankException(e.getMessage());
		}
	}

	private static void login()
	{
		try
		{
		new OnlineBankingSystemUI();
		boolean userLogin;
		boolean lockStatus;
		int pwdChoice;
		System.out.println("***************************************Welcome to Online Banking System**********************************************\n");
		System.out.println("Login as : 1.User  2.Admin");
		String logger = br.readLine();
		if(logger.equals("1"))
		{
			System.out.println("Enter your userId:	");
			userId = Integer.parseInt(br.readLine());
			try {
				if(userService.validateUserId(userId) == true)
					{
					System.out.println("1.Enter password  2.Forgot Password");
					pwdChoice = Integer.parseInt(br.readLine());
					if(pwdChoice == 1)
					{	
					System.out.println("Enter your user password ");	
					userPassword = br.readLine();
					userLogin = userService.validateLogin(userId, userPassword);
					lockStatus = userService.validateLockStatus(userId);
						if(userLogin == true && lockStatus == true) 
							{
	
							customer = transactionService.getData(userId); 
							userHomePage(userId);
							System.out.println("1.User Home Page 2.Logout");
							
							choice = Integer.parseInt(br.readLine());
							while(choice == 1)
							{
								userHomePage(userId);							
								choice = 0;
								System.out.println("1.User Home Page 2.Logout");
								choice = Integer.parseInt(br.readLine());
							}
							}
						else
						{ throw new BankException("Invalid Password");}
						}
					else if(pwdChoice == 2)
					{
						System.out.println("Who is your favourite person?");
						String secAns = br.readLine();
						if(userService.validateSecurityQuestion(secAns, userId))
						{
							System.out.println("Your reset password is sent to your registered mail. Please check in your mail inbox");
							System.out.println("Enter the reset password");
							String forgotPwd = br.readLine();
							
							
							
							lockStatus = userService.validateLockStatus(userId);
							if(userService.validateForgotPassword(forgotPwd) == true && lockStatus == true)
							{
								setNewPwd(userId);
								customer = transactionService.getData(userId); 
								userHomePage(userId);
								System.out.println("1.User Home Page 2.Logout");
								
								choice = Integer.parseInt(br.readLine());
								while(choice == 1)
								{
									userHomePage(userId);							
									choice = 0;
									System.out.println("1.User Home Page 2.Logout");
									choice = Integer.parseInt(br.readLine());
								}
							}
							else
							{ throw new BankException("Invalid Password");}
						}
						else
							throw new BankException("Not a correct answer");
					}
					}
			}
			catch (BankException e) 
			{
				//e.printStackTrace();
				System.out.println(e);
			}
		}
		else if(logger.equals("2"))  //admin part
		{
			
			System.out.println("Enter Id:	");
			adminId = br.readLine();
			try {

					System.out.println("Enter your password:	");
					adminPassword = br.readLine();
					System.out.println(adminId+"  "+adminPassword);
					if(userService.validateAdminLogin(adminId,adminPassword) == true)
					{
							adminHomePage(adminId);
							System.out.println("1.Admin Home Page 2.Logout");
							
							choice = Integer.parseInt(br.readLine());
							while(choice == 1)
							{
								adminHomePage(adminId);								
								choice = 0;
								System.out.println("1.Admin Home Page 2.Logout");
								choice = Integer.parseInt(br.readLine());
							}
							
					}
			}
			catch (BankException e) 
			{
				e.printStackTrace();
				System.out.println(e);
			}
			
		}
		else
		{
			System.out.println("Enter a valid input");
		}
		}
	catch(IOException e)
		{
		e.printStackTrace();
		}
		
	}

	public static void main(String[] args)throws IOException 

	{
		login();
		while(true) {
			System.out.println("Do you want to login again?\nChoose an option\n1.Yes\n2.No");
			int choice = Integer.parseInt(br.readLine());
			switch(choice) {
			case 1:login();
				   break;
			case 2:System.exit(1);
			default: System.out.println("Incorrect choice");
			}
		}
		

		
	}
	
	private static void adminHomePage(String adminId)
	{
		
		System.out.println("*****************************************HomePage***************************************************\n\n\n");
		System.out.println("\t\t Welcome admin to our Online Banking System");
		try {
			int adminChoice;
			System.out.println("1.Create New Account page\n2.View transactions of all accounts\n");
			adminChoice=Integer.parseInt(br.readLine());
			switch(adminChoice)
			{
			case 1:{createNewAccount();
					adminHomePage(adminId);
					break;}
			case 2:viewAllTransactions();
					break;
			default:System.out.println("Invalid input");
			}
	}
		
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	
			
	
	private static void viewAllTransactions() {
		int period;
		System.out.println("1.Daily transactions 2.Monthly transaction 3.Yearly transactions");
		try
		{
		int userchoice=Integer.parseInt(br.readLine());
		ArrayList<Transactions> list;
		switch(userchoice)
		{
		case 1:System.out.println("Enter date in format dd-MM-yyyy");
				String date=br.readLine();
				DateTimeFormatter format=DateTimeFormatter.ofPattern("dd-MM-yyyy");

				LocalDate formatedDate=LocalDate.parse(date,format);
				list=transactionService.viewTransaction(formatedDate);
				for(Transactions trans:list)
				{
					System.out.println(trans);
				}
				break;
		case 2:System.out.println("Enter month number");
				period=Integer.parseInt(br.readLine());
				list=transactionService.viewTransaction(period,"monthly");
				for(Transactions trans:list)
				{
					System.out.println(trans);
				}
				break;
		case 3:
			System.out.println("Enter year");
			period=Integer.parseInt(br.readLine());
			list=transactionService.viewTransaction(period,"yearly");
			for(Transactions trans:list)
			{
				System.out.println(trans);
			}
			break;
		}
		}
		catch (BankException e) 
		{
			System.out.println(e);
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
	}

//Change made by naguleshan on 23/09/2019
	private static void createNewAccount(){
		
		try 
		{
	
			while(true)
			{
			System.out.println("Enter user ID");
			System.out.println("UserId must contain only digits of length 6");
			int uid= Integer.parseInt(br.readLine());
			if(accountService.validateUserId(uid))
			{
			System.out.println("Enter Account Holder Name");
			System.out.println("Name must begin with capital letter with minimum 5 and maximum 20 characters");
			String  custName= br.readLine();
			
			if(accountService.validateName(custName))
			{	
			System.out.println("Enter Account Holder Password: ");
			System.out.println("Passowrd must contain one digit, one lowercase letter and a special character with min length 6 and max length 20");
			String  custPwd= br.readLine();
			
			if(accountService.validatePassword(custPwd))
				{
				System.out.println("Enter the same password again");
				System.out.println("Confirm Password");				
				String  confPwd= br.readLine();
			
				if(accountService.confirmPassword(custPwd, confPwd))
				{
					System.out.println("Enter Account Holder Email");
					String  custEmail= br.readLine();
			
					if(accountService.validateMail(custEmail))
					{
						System.out.println("Enter Account Holder Address");
						String  custAddr= br.readLine();
						
						System.out.println("PAN must contain 5 capital letters in start and followed by 4 digits ");
						System.out.println("Enter Account Holder Pan");
						String  custPAN=(br.readLine());
						if(accountService.validatePAN(custPAN))
						{
							System.out.println("Security Question :");
							System.out.println("Who is your favourite person?");
							String custQues=(br.readLine());
			
							System.out.println("Enter Account Holder Transaction password");
							System.out.println("Transaction Passowrd must contain one digit, one lowercase letter and a special character with min length 6 and max length 20");
							String custTPwd= (br.readLine());
							if(accountService.validatePassword(custPwd))
							{
								System.out.println("Enter Account Type");
								String accType= (br.readLine());
			
								System.out.println("Enter Account holder's mobile no.");
								System.out.println("Mobile number must be exactly 10 digits");
								long custMob= Long.parseLong(br.readLine());								
								if(accountService.validateMobileNumber(custMob))
								{
									System.out.println("Enter Account Holder's balance");
									double balance= Double.parseDouble(br.readLine());
									boolean add = accountService.addAccount(uid,custName, custEmail, custAddr, custPAN, custPwd, custQues, custTPwd, accType, custMob, balance);
									if(add==true)
										{ System.out.println("User added successfully!");
										  break;
										}
									else 
										{
										System.out.println("Creating new Account is unsuccessfull");
										break;
										}
								}
								else
									System.out.println("Enter a valid mobile number...Mobile number must be exactly 10 digits\nPlease refill the form");
							}
							else
								System.out.println("Enter a valid Transaction Password...Passowrd must contain one digit, one lowercase letter and a special character with min length 6 and max length 20\nPlease refill the form");
						}
						else
							System.out.println("Enter a valid PAN...\nPAN must contain 5 capital letters in start and followed by 4 digits \nPlease refill the form");
					}
					else
						System.out.println("Enter a valid Mail ID...\nPlease refill the form");
					
				}				
				else
					System.out.println("Password does not match...Enter the same password again\nPlease refill the form");
				}
				else
					System.out.println("Enter a valid User Password...Passowrd must contain one digit, one lowercase letter and a special character with min length 6 and max length 20\nPlease refill the form");
			}
			else
				System.out.println("Enter a valid UserName....Name must begin with capital letter with minimum 5 and maximum 20 characters\nPlease refill the form");
			}
			else
				System.out.println("Enter a valid userID...UserId must contain only digits of length 6\nPlease refill the form");
			} 
		}
		catch (BankException e) 
		{
			System.out.println(e);
		}
		
		catch(IOException e)
		{
			System.out.println(e);
		}
	}
	

	private static void viewMini(long accNo)
	{
			try 
			{
				ArrayList<Transactions> list=transactionService.viewMini(accNo);
				for(Transactions list1: list) {
					System.out.println(list1);
				}
			}
			catch (BankException e) 
			{
					System.out.println(e.getMessage());
			}
				
	}
	
	private static void viewDetailed(long accNo, LocalDate startDate, LocalDate endDate)
	{
		try 
		{
			ArrayList<Transactions> list=transactionService.viewDetailed(accNo, startDate, endDate);
			try 
			{
				for(Transactions t1:list)
					System.out.println(t1);
			}
			catch (Exception e) 
			{
					e.printStackTrace();
			}
		} 
		
		catch (BankException e) 
		{
			System.out.println(e);
			e.printStackTrace();
		}
				
	}
	
	private static void requestCheque()
	{
		try 
		{
			System.out.println("Select the Account Number from the given list :\n");
			ArrayList<Long> allAccounts = userService.getAccounts(userId);
			int listNo=0;
			for(long acc : allAccounts)
				{ System.out.println((++listNo)+"."+acc); }
			int userChoice = Integer.parseInt(br.readLine());
			if(userChoice >=1 && userChoice <= listNo)
			{
					long accNo = allAccounts.get(--userChoice);
					if(serviceTrackerService.requestCheque(accNo)>0)
					{
						System.out.println("Cheque Book request is raised Successfully");
					}
					else
					{
						//if cheque request is already raised
						System.out.println("Your Cheque Book request is already raised. Track your service request.");
					}
			}
			else
				System.out.println("Enter valid choice ");			

		} 
		catch (BankException e) {
			System.out.println(e);
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
	}
	
	private static void searchByAccNo(long accNo) 
	{
		try 
		{
			HashMap<Integer,String> hmap=serviceTrackerService.searchByAccNo(accNo);
			Set<Entry<Integer,String>> hashSet=hmap.entrySet();
	        for(Entry<Integer,String> entry:hashSet ) {
	            System.out.println("id="+entry.getKey()+", Status="+entry.getValue());
	        }
		} 
		catch (BankException e)
		{
			System.out.println(e);
			e.printStackTrace();
		}
		
	}
	//changePwd done by nagulesh on 23/09/2019	
		private static void changePwd(int userId)
		{
			try 
			{
				System.out.println("Enter your password:	");
				userPassword = br.readLine();
				boolean validatePwd = userService.validateOldPassword(userId, userPassword);
				if(validatePwd == true)
				{
					setNewPwd(userId);
				}
			else
				throw new BankException("The Old password is incorrect...");
			}
				
			catch (BankException e) {
				System.out.println(e);
				e.printStackTrace();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}
		
		//setNewPwd done by nagulesh on 23/09/2019	
		private static void setNewPwd(int userId)
		{
			try 
			{
				System.out.println("Enter new password  :    ");
				System.out.println("Remember --> Passowrd must contain one digit, one lowercase letter and a special character with min length 6 and max length 20");
				String newPwd=br.readLine();
				boolean newPwdValidate = userService.validatePassword(newPwd) ;
				while(true)
				{
					if(newPwdValidate)
					{	
						System.out.println("Confirm password");
						System.out.println("Enter the new Password again");
						String confPwd=br.readLine();
						boolean res = userService.confirmPassword(newPwd, confPwd);
						while(true)
							{
								if(res)
									{
										boolean isChanged=userService.changePwd(userId, newPwd);
				
										if(isChanged)
										{
											System.out.println("Password is changed successfully");
										}
										else
											System.out.println("Operation cannot be completed");
										break;
									}
								else
									{
									System.out.println("Password mismatch...Password must be same");
									System.out.println("Enter Confirm password again");
									confPwd=br.readLine();
									res = userService.confirmPassword(newPwd, confPwd);
									}
							}
						break;
					}
				else
				{
				System.out.println("Passowrd must contain one digit, one lowercase letter and a special character with min length 6 and max length 20");
				System.out.println("Enter the new password again");
				newPwd=br.readLine();
				newPwdValidate = userService.validatePassword(newPwd) ;
				}
				}
			
				
			} 
			catch (BankException e) {
				System.out.println(e);
				e.printStackTrace();
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}

	private static boolean otherBankFundTransfer()
	{
		try
		{
		payeeService = new PayeeServiceImpl();
		System.out.println("From:	");
		System.out.println("\t\tSelect the Account Number from the below list");
		ArrayList<Long> allAccounts = userService.getAccounts(userId);
		int listNo=0;
		for(long acc : allAccounts)
		{
			System.out.println((++listNo)+"."+acc); 
		}
		int userChoice =Integer.parseInt(br.readLine());
		if(userChoice >=1 && userChoice <= listNo)
			{
				long fromAccNo = allAccounts.get(--userChoice);
				System.out.println("To:	");
				System.out.println("\t\t1.Payee list 2.Add Payee and continue");
				userChoice = Integer.parseInt(br.readLine());
				if(userChoice==1)
				{
					System.out.println("\t\tSelect the Account Number from the Payee list");
					ArrayList<PayeeTable> payeeAccounts = payeeService.getPayee(fromAccNo);
					listNo=0;
					System.out.printf("\n%20s	%20s %20s","S.No","NickName","Account Id");
					for(PayeeTable payee : payeeAccounts)
					{ 
						System.out.printf("\n%20s	%20s %20s",(++listNo),payee.getNick_name(),payee.getPayee_account_id());
					}
						userChoice = Integer.parseInt(br.readLine());
						if(userChoice>=1 && userChoice<=listNo)	
						{	PayeeTable toAccNo = payeeAccounts.get(--userChoice);
						
							System.out.println("Enter the amount to be transferred");
							int amt = Integer.parseInt(br.readLine());

							boolean debitLimitValue = transactionService.debitLimitValueCheck(fromAccNo,amt);

							if(debitLimitValue)							

							{System.out.println("Enter the transaction password");


							String tranPwd = br.readLine();
							//Validation for transaction password pending
							System.out.println(transactionService.addTransaction(fromAccNo, toAccNo.getNick_name() , amt, tranPwd));
							}
							else
								System.out.println("Debit Limit Reached......Unable to transfer the amount");
						}
						else
							System.out.println("Enter a valid input");
				}	
				else if(userChoice==2)
				{
					System.out.println("Enter Payee Nick Name");
					String  payeeName= br.readLine();
					
					System.out.println("Enter Payee Account Id");
					long payeeAccId =Long.parseLong(br.readLine());
					
					System.out.println("Enter URN");
					String urn=br.readLine();
					
					if(payeeService.validateURN(urn))
					{
					PayeeTable newPayee = new PayeeTable(fromAccNo, payeeAccId, payeeName);
					payeeService.addPayee(newPayee);
					
					System.out.println("Now proceed the transaction");
					
					System.out.println("To:	");
					System.out.println("Payee list");

						System.out.println("\t\tSelect the Account Number from the Payee list");
						ArrayList<PayeeTable> payeeAccounts = payeeService.getPayee(fromAccNo);
						listNo=0;
						System.out.printf("%20s	%20s %20s","S.No","NickName","Account Id");
						for(PayeeTable payee : payeeAccounts)
						{ 
							System.out.printf("%20s	%20s %20s",(++listNo),payee.getNick_name(),payee.getPayee_account_id());
						}
						userChoice = Integer.parseInt(br.readLine());
						if(userChoice>=1 && userChoice<=listNo)	
						{	PayeeTable toAccNo = payeeAccounts.get(--userChoice);
						
							System.out.println("Enter the amount to be transferred");
							int amt = Integer.parseInt(br.readLine());
							System.out.println("Enter the transaction password");
							String tranPwd = br.readLine();
							//Validation for transaction password pending
							System.out.println(transactionService.addTransaction(fromAccNo, toAccNo.getNick_name() , amt, tranPwd));
				
						}
						else
							System.out.println("Enter a valid input");
					}
					System.out.println("Invalid URN\nFailed to add payee");			
				}
			}
		}
		catch (BankException e) {
			System.out.println(e);
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		return true;
	}
	
	private static boolean ownBankFundTransfer()
	{
		try
		{
		System.out.println("From:	");
		System.out.println("\t\tSelect the Account Number from the below list");
		ArrayList<Long> allAccounts = userService.getAccounts(userId);
		int listNo=0;
		for(long acc : allAccounts)
			{ System.out.println((++listNo)+"."+acc); }
		int userChoice = Integer.parseInt(br.readLine());
		if(userChoice >=1 && userChoice <= listNo)
		{
				long fromAccNo = allAccounts.get(--userChoice);
				System.out.println("To:	");
				System.out.println("\t\tSelect the Account Number from the below list");
				listNo=0;
				for(long acc : allAccounts)
					{ ++listNo;
					if(listNo!=userChoice)
						System.out.println((listNo)+"."+acc); 
					}
				//long toAccNo = allAccounts.get(userChoice);
				long toAccNo = Integer.parseInt(br.readLine());
				System.out.println("Enter the amount to be transferred");
				int amt = Integer.parseInt(br.readLine());
				System.out.println("Enter the transaction password");
				String tranPwd = br.readLine();
				boolean valid = userService.validateTransPwd(fromAccNo,tranPwd);
				if(valid==true)
				{
					fundTransferService.transferToSelf(fromAccNo, toAccNo, amt);
					System.out.println("Transaction successful!");
				}
				else 
					System.out.println("Incorrect Password");
				
				
		}	
		}
		catch (BankException e) {
			System.out.println(e);
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		return true;
	}
	private static void fundTransfer()
	{
		try 
		{
			fundTransferService = new FundTransferServiceImpl();
			System.out.println("*******************************Fund Transfer*******************************");
			System.out.println("1.Own Bank Account 2.Different Bank Account");
			int userChoice = Integer.parseInt(br.readLine());
			switch(userChoice)
			{
			case 1: ownBankFundTransfer();
					break;
			case 2: otherBankFundTransfer();
					break;
			default:
				    System.out.println("Enter a valid choice");
					
			}
			
			
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
}



