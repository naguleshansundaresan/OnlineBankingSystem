package com.cg.obs.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.obs.dao.CustomerDaoImpl;
import com.cg.obs.exception.BankException;

import junit.framework.Assert;

public class ChangeAddressTest {

	
	static CustomerDaoImpl custDao = null;
	
	@BeforeClass
	public static void setUp()
	{
		custDao = new CustomerDaoImpl();

	}
	
	@AfterClass
	public static void atEnd()
	{
		System.out.println("Change Address function is tested successfully");
	}
	
	@Before
	public void befTest()
	{
		System.out.println("Test starts");
	}
	
	@After
	public void aftTest()
	{
		System.out.println("Test ends");
	}
	
	
	@Test
	public void forgotPwdValidateTestPass() throws BankException
	{
		try {
			Assert.assertEquals(true,custDao.updateAddress(1000009, "pune"));
		} catch (BankException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	public void forgotPwdValidateTestFail() throws BankException
	{
		try {
			Assert.assertEquals(false,custDao.updateAddress(1000, "pune"));
		} catch (BankException e) {
			
			e.printStackTrace();
		}
	}
}
